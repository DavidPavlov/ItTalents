
public class Problem4 {
	public static void main(String[] args) {
		for (int i = 10; i >= 1; i--) {
			System.out.print(i);
			if (i != 1) {
				System.out.print(" ");
			}

		}
	}
}
