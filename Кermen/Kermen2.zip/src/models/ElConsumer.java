package models;

public class ElConsumer {
	private double elCost;

	public ElConsumer(double elCost) {
		this.elCost = elCost;
	}

	public double getElCost() {
		return elCost;
	}

}
