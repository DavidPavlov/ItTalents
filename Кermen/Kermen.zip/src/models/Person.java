package models;

public class Person {
	private double salary;

	public Person(double salary) {
		this.salary = salary;
	}

	public double getSalary() {
		return salary;
	}

}
