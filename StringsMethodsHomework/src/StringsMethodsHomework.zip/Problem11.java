
public class Problem11 {

	public static void main(String[] args) {
		int[] arr = { 3, 4, 7, 1, 2, -17, 1, 8, 23 };
		printArray(arr);

	}

	static void printArray(int[] array) {
		for (int i = 0; i < array.length; i++) {
			System.out.print(array[i] + " ");
		}
	}
}
