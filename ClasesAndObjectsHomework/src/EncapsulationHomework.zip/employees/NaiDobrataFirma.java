package employees;

public class NaiDobrataFirma {
	public static void main(String[] args) {
		Task task = new Task("Creating the new Facebook", 100);
		Task task2 = new Task("Implementing interpolation search", 3);

		Employee ivan = new Employee("Ivan");
		ivan.setCurrentTask(task);
		ivan.setHoursLeft(12);
		Employee maria = new Employee("Maria");
		maria.setCurrentTask(task2);
		maria.setHoursLeft(8);
		ivan.work();
		maria.work();
	}
}
