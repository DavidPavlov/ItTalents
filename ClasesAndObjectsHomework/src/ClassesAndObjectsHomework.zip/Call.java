
public class Call {

	static final double priceForMinute = 0.22d;

	String caller;
	String receiver;
	int duration;

}
